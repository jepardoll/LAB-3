module top(
    input clk,                // Clock de la FPGA
    output reg [6:0] seg_uni, // Display unidades
    output reg [6:0] seg_dec  // Display decenas
);

    
    // DIVISOR DE FRECUENCIA 
    
    reg [25:0] divisor = 0;

    
    // CONTADORES BCD
    
    reg [3:0] unidades = 0;
    reg [3:0] decenas  = 0;

    
    // GENERAR PULSO DE CONTEO
   
    always @(posedge clk) begin

        // MODIFICACIÓN: Cambiado de 49999999 a 4 para simular 
      if(divisor == 4) begin

            divisor <= 0;

           
            // CONTADOR DE SEGUNDOS
            
            if(unidades == 9) begin
                unidades <= 0;
              if(decenas == 5)
                    decenas <= 0;
                else
                    decenas <= decenas + 1;
            end
            else begin
                unidades <= unidades + 1;
            end

        end
        else begin
            divisor <= divisor + 1;
        end
    end

    
    // DECODER DISPLAY UNIDADES
    
    always @(*) begin
        case(unidades)
            4'd0: seg_uni = 7'b1111110;
            4'd1: seg_uni = 7'b0110000;
            4'd2: seg_uni = 7'b1101101;
            4'd3: seg_uni = 7'b1111001;
            4'd4: seg_uni = 7'b0110011;
            4'd5: seg_uni = 7'b1011011;
            4'd6: seg_uni = 7'b1011111;
            4'd7: seg_uni = 7'b1110000;
            4'd8: seg_uni = 7'b1111111;
            4'd9: seg_uni = 7'b1111011;
            default: seg_uni = 7'b0000000;
        endcase
    end

    
    // DECODER DISPLAY DECENAS
    
    always @(*) begin
        case(decenas)
            4'd0: seg_dec = 7'b1111110;
            4'd1: seg_dec = 7'b0110000;
            4'd2: seg_dec = 7'b1101101;
            4'd3: seg_dec = 7'b1111001;
            4'd4: seg_dec = 7'b0110011;
            4'd5: seg_dec = 7'b1011011;
            4'd6: seg_dec = 7'b1011111;
            4'd7: seg_dec = 7'b1110000;
            4'd8: seg_dec = 7'b1111111;
            4'd9: seg_dec = 7'b1111011;
            default: seg_dec = 7'b0000000;
        endcase
    end

endmodule