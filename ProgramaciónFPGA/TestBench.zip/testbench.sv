`timescale 1ns / 1ps

module tb_top;
    
    reg clk;
    wire [6:0] seg_uni;
    wire [6:0] seg_dec;
   
    top dut (
        .clk(clk),
        .seg_uni(seg_uni),
        .seg_dec(seg_dec)
    );

    
    
    initial begin
        
        $dumpfile("dump.vcd");
        
        // El '0' indica que guarde las ondas de este módulo y 
        // de todos los submódulos internos 
        $dumpvars(0, tb_top); 
	    // VISUALIZACIÓN EN CONSOLA 
               $monitor("Tiempo: %0t ns | clk: %b | Decenas: %b | Unidades: %b", 
                 $time, clk, seg_dec, seg_uni);

        clk = 0;
        
        // Mantenemos el tiempo en 5000 asumiendo que el módulo 'top' 
        // Tiene la modificación rápida (divisor == 4).
        #6000; 
        
        $finish;
    end

    
    always begin
        #10 clk = ~clk; // Genera el reloj simulado de 50 MHz
    end

endmodule